/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cltech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Andres Cruz
 */
class Conexion {
     public static Connection getConexion() {
         //        try {
//            String connectionUrl
//                    = "jdbc:sqlserver://localhost:1433;"
//                    + "databaseName=master;integratedSecurity=true;"
//                    + "encrypt=true; trustServerCertificate=false;"
//                    + "trustStore=storeName;trustStorePassword=storePassword";
//            Connection conect = DriverManager.getConnection(connectionUrl);
//            System.out.println("Conectado.");
//        } catch (SQLException ex) {
//            System.out.println("Error.");
//        }
        try {
           String conexionUrl = "jdbc:mysql://localhost:3306/CLTech?user=root&password=";

            Connection conect = DriverManager.getConnection(conexionUrl);
            System.out.println("Conectado.");
            return conect;
        } catch (SQLException ex) {
            System.out.println("Error.");
            ex.printStackTrace();
            return null ; 
    }
       
    }
    
}
