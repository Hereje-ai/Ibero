/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sockets;

/**
 *
 * @author Andres Cruz
 */
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class Esclavo {
    public static void main(String[] args) throws ClassNotFoundException {
           try {
             //Crear servidor de sockets
            ServerSocket serverSocket = new ServerSocket(9000);
            
            while (true) {
                System.out.println("Escuchando...");
                // Esperar conexión del maestro
                Socket socket = serverSocket.accept();
                // Obtener streams de entrada y salida
                ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                
                // Leer solicitud del maestro
                String solicitud = (String) in.readObject();
                
                if (solicitud.equals("lista")) {
                    // Crear y enviar lista de objetos al maestro
                    List<Object> lista = new ArrayList<>();
                    lista.add("Tareas 1");
                    lista.add("Tareas 2");
                    lista.add("Tareas 3");
                    lista.add("Tareas 4");
                    lista.add("Tareas 5");
                    lista.add("Tareas 6");
                    out.writeObject(lista);
                    out.flush();
                }
                
                // Cerrar streams y socket
                out.close();
                in.close();
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
       }
    }
}

